疑似ブクマ

#　お役立ち

##　Git

- 図解！ Gitのブランチ・ツリーをちゃんと読む
[https://qiita.com/jesus_isao/items/2a0495c973a4c911c2cc]

- リポジトリ内のブランチを表示する
[https://docs.github.com/ja/repositories/configuring-branches-and-merges-in-your-repository/managing-branches-in-your-repository/viewing-branches-in-your-repository]

#後で読む（要検証）

- GUIで実践！GitHub入門ハンズオン（with VSCode)
[https://qiita.com/yoshi111/items/3a991a58de4f37d73921]